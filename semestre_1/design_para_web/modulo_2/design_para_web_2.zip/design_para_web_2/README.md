# Design para web - Atividade 2

Este é a atividade realizada para a Matéria de Design para a web do primeiro semeste de Sistemas para Internet - UAM 

Segue abaixo a descrição da Atividade 

## Vamos Praticar

Olá, aluno. Todo e qualquer negociante, do pequeno ao grande, deve ter seu endereço eletrônico na Internet. Então, quero te propor um desafio. Desenvolva um layout de página microempresário individual (MEI). Utilizando os conceitos de semântica WEB utilizada na linguagem de marcação HTML5, crie uma página index e faça os comentários de uso dos elementos da linguagem, ressaltando o porquê do uso desses elementos. Ao final, disponibilize seu trabalho no fórum da seção.

Clique [aqui](https://dennisberg13100.github.io/design_para_web_atividade2/) para acessar o site. 